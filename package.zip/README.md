## Installation
To add to chrome:
- go to Extensions, make sure Developer Mode is enabled
- Load Unpacked and choose the root dir of this repo

## Updating the extension
### If you cloned the repo
Pull changes and then go to extensions and reload extension
### If you downloaded zip
Re-download and overwrite then go to extensions and reload extension


